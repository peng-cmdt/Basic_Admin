
namespace PurestAdmin.Application.AssetServices.Dtos;
public class GetPagedListInput : PaginationParams
{
    
}
