
namespace PurestAdmin.Application.AssetServices.Dtos;
public class AssetOutput
{
	/// <summary>
	/// 
	/// </summary>
	public string Id { get; set; }
	/// <summary>
	/// 
	/// </summary>
	public string AssetId { get; set; }
	/// <summary>
	/// 
	/// </summary>
	public string AssetType { get; set; }
	/// <summary>
	/// 
	/// </summary>
	public string AssetBrand { get; set; }
	/// <summary>
	/// 
	/// </summary>
	public string AssetModel { get; set; }
	/// <summary>
	/// 
	/// </summary>
	public string AssetSeries { get; set; }
	/// <summary>
	/// 
	/// </summary>
	public string ServerTag { get; set; }
	/// <summary>
	/// 
	/// </summary>
	public string AssignUser { get; set; }
	/// <summary>
	/// 
	/// </summary>
	public string Warranty { get; set; }
	/// <summary>
	/// 
	/// </summary>
	public DateTime? PurchaseDate { get; set; }
	/// <summary>
	/// 
	/// </summary>
	public string Remark { get; set; }
	/// <summary>
	/// 
	/// </summary>
	public string AssetName { get; set; }
	/// <summary>
	/// 
	/// </summary>
	public string AssetStatus { get; set; }
	/// <summary>
	/// 
	/// </summary>
	public string LastUser { get; set; }
}
